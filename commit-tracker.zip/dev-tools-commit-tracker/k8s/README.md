# Info

## Graph manifests

Generated from cxp-deployments/k8s/local

* account-link
* user

## Secrets

The secrets are to the (well-known) connection string for the cosmos db emulator

## GraphQL Gateway manifests

Written for testing GraphQL federated gateway services

* graphql.gateway - uses federated stitching as documented on the chili cream site
* graphql.fusion.gateway - uses 'Fusion' federation. very little documentation regarding this framework