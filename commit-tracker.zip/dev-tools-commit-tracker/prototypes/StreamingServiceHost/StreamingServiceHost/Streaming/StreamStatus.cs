namespace NGrid.Customer.Framework.StreamingServiceHost.Streaming;

public enum StreamStatus
{
    Running,
    Finished
}