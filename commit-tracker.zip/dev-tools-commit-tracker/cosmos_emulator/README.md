# Info

Kubernetes manifests to deploy an instance of the Cosmos DB emulator to a kubernetes cluster

This can be used with Rancher Desktop.
