namespace FakeDataLoader.CustomGenerators;

public enum CustomGeneratorFieldName
{
    AccountNumber,
    Zip
}