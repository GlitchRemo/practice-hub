namespace FakeDataLoader.CustomGenerators;

public interface ICustomGenerator
{
    public object Generate();
}