namespace FakeDataLoader.Models;

public enum SupportedType
{
    String,
    Number,
    Date,
    Bool,
    Null
}